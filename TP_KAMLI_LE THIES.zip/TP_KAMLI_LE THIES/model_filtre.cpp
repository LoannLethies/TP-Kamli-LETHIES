#include "model_filtre.h"

using namespace cv;


Mat Model_filtre::load()  //chargement de l'image
{
	Mat img = imread("Lena.jpg");
	imshow("Originale", img);  //afficher l'image originale
	return img;
}

void Model_filtre::filtre_median()  //definition du filtre median
{
	Mat src = load();  //utilisation de la fonction qui charge l'image originale
	Mat dst;
	for (int i = 1; i < 50; i = i + 2)
	{
		medianBlur(src, dst, i);  //Apllication du filtre 
	}
	View_filtre::afficher("Apr�s modification", dst);  //Affichage du filtre
}

void Model_filtre::filtre_gaussien()  //definition du filtre gaussien
{
	Mat src = load();
	Mat dst;
	for (int i = 1; i < 50; i = i + 2)
	{
		GaussianBlur(src, dst, Size(i, i), 0, 0);  //Apllication du filtre 
	}
	View_filtre::afficher("Apr�s modification", dst);  //Affichage du filtre
}

void Model_filtre::gradient()  //definition du filtre gradient
{
	load(); //chargement de l'image originale
	Mat image = cv::imread("Lena.jpg", IMREAD_GRAYSCALE);  //Image a modifier
	waitKey();  
	Mat image_X;
	Sobel(image, image_X, CV_8UC1, 1, 0);  //Apllication du filtre a partir de l'image original pour donner l'image "image_X"
	View_filtre::afficher("Apr�s modification", image_X);  //Affichage
}

void Model_filtre::dilatation()  //definition du filtre dilatation
{
	Mat src = load(), dilation_dst;
	int dilation_elem = 1;
	int dilation_size = 8;  //initialisation des constantes
	int dilation_type = 4;
	if (dilation_elem == 0) { dilation_type = MORPH_RECT; }
	else if (dilation_elem == 1) { dilation_type = MORPH_CROSS; }  //Modification du filtre en fonction des parametres choisis
	else if (dilation_elem == 2) { dilation_type = MORPH_ELLIPSE; }
	Mat element = getStructuringElement(dilation_type,
		Size(2 * dilation_size + 1, 2 * dilation_size + 1),  //Modification du filtre en fonction des parametres choisis
		Point(dilation_size, dilation_size));
	dilate(src, dilation_dst, element);
	View_filtre::afficher("Apr�s modification", dilation_dst);  //Affichage de l'image
}

void Model_filtre::erosion()  //Application du filtre erosion
{
	load();  //chargement de l'image originale
	Mat dst, src = imread("Lena.jpg", IMREAD_GRAYSCALE);
	int erosion_type;
	int erosion_elem = 2;
	int erosion_size = 7;
	if (erosion_elem == 0) { erosion_type = MORPH_RECT; }
	else if (erosion_elem == 1) { erosion_type = MORPH_CROSS; }  //Modification du filtre en fonction des parametres choisis
	else if (erosion_elem == 2) { erosion_type = MORPH_ELLIPSE; }

	Mat element = getStructuringElement(erosion_type,
		Size(2 * erosion_size + 1, 2 * erosion_size + 1),  //Modification du filtre en fonction des parametres choisis
		Point(erosion_size, erosion_size));
	
	erode(src, dst, element); //Application du filtre erosion
	View_filtre::afficher("Apr�s modification", dst);  //Affichage de l'image modifiee
}

void Model_filtre::detecteur_contour()  //filtre detecteur de contour
{
	load();  //chargement de l'image originale
	Mat src1 = imread("Lena.jpg");
	namedWindow("Original image");
	Mat gray, edge, draw;
	cvtColor(src1, gray, COLOR_BGR2GRAY);

	Canny(gray, edge, 50, 150, 3);  //Application filtre

	edge.convertTo(draw, CV_8U);
	namedWindow("image");
	View_filtre::afficher("Apr�s modification", draw);  //affichage
}

void Model_filtre::seuillage()
{
	load();
	Mat src = imread("Lena.jpg") ; 
	Mat dst;
	double thresh = 0;
	double maxValue = 255;
	threshold(src, dst, thresh, maxValue, THRESH_BINARY);  //application filtre
	waitKey(5000);
	threshold(src, dst, 115, 255, 2);  //application filtre
	View_filtre::afficher("Apr�s modification", dst);  
	
}

void Model_filtre::segmentation()
{
	std::cout << "Filtre non disponible." << std::endl;
}
