#ifndef MODEL_H
#define MODEL_H


#include "view_filtre.h"
#include <opencv2/opencv.hpp>
#include <string>
#include <iostream>

using namespace cv;
using namespace std;

class Model_filtre : public View_filtre //Mise en place d'une hierarchie entre les classes.
//Model_filtre peut maintenant utiliser les fonctions de View_filtre.
{
public:  
	Mat load();  //Creation des fonctions permettant la realisation des filtres.
	void filtre_median();
	void filtre_gaussien();
	void gradient();
	void dilatation();
	void erosion();
	void detecteur_contour();
	void seuillage();
	void segmentation();
};

#endif