#include "model_filtre.h"     //liaison entre les fichiers
#include "view_filtre.h"
#include "controller_filtre.h"
#include <opencv2/opencv.hpp>  //bibliotheque d'opencv
#include <iostream>
#include <string>

using namespace cv;   //permet de ne pas avoir a ecrire std::
using namespace std;

int main()
{
	int choix;
	cout << "Modifications d'images\n " <<endl;
	cout << "Choisissez votre modification: \n 1 - Filtre median \n 2 - Filtre gaussien \n 3 - Gradient"
		<< "\n 4 - dilatation \n 5 - Erosion \n 6 - Detecteur de contours \n 7 - Seuillage \n 8 - Segmentation" << endl;
	cin >> choix;
	Controller_filtre sujet;  //creation d'un objet de la classe Controller_filtre
	sujet.filtre(choix);     //application de la fonction permettant de choisir son filtre a l'objet
}

