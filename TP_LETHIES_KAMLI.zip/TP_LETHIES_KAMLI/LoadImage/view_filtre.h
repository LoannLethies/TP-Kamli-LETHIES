#ifndef VIEW
#define VIEW

#include <opencv2/opencv.hpp>
#include <iostream>
#include <string>

using namespace cv;
using namespace std;

class View_filtre
{
public:
	View_filtre();
	void afficher(string name, Mat obj);

};
#endif
