#ifndef CONTROLER_H
# define CONTROLER_H
#include <iostream>
#include "model_filtre.h"

class Controller_filtre : public Model_filtre  //Mise en place d'une hierarchie entre les classes.
//Controller_filtre peut maintenant utiliser les fonctions de Model_filtre.
{
public:
	void filtre(int choice);
};
#endif