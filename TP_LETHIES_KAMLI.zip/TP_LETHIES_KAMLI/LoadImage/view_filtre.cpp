#include "view_filtre.h"

View_filtre::View_filtre()
{
}

void View_filtre::afficher(string name, cv::Mat obj)
{
	imshow(name, obj);
	waitKey(0);
}
